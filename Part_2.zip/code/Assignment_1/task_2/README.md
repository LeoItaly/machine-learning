A detailed explanation of the attributes of the data.
 Describe if the attributes are discrete/continuous, Nominal/Ordinal/In-
terval/Ratio,
 Give an account of whether there are data issues (i.e. missing values or
corrupted data) and describe them if so.
 Include basic summary statistics of the attributes.
If your data set contains many similar attributes, you may restrict yourself to
describing a few representative features (apply common sense).