# intro-to-ml

models to train:
REGRESSION - life expectancy
- linear regr P1
- ANN P3

CLASSIFICATION - developed / developing
- logistic regr P2
- arbitrary P3

DISCUSSION
- comparison to prev work P2

P1 - Leo
P2 - Rasmus
P3 - Andris
